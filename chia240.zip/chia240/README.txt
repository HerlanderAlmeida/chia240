Steps
https://github.com/HerlanderAlmeida/chia240




BTC: bc1q2pmtjkca20jq8ygvkf9vxlpffx4ww04prx3ear
ETH: 0x9D32759012Fe12f528c5FE4dFB25812BC6079e40
XCH: xch1g2tsmg5fs69zuc8l9ahqyunp8zxxx7x9cr74qa949sm2wqcg7xusnpczqn
DOGE: D5RNhezuTsE179VYHcQd76ftrXTVnSMtnJ

